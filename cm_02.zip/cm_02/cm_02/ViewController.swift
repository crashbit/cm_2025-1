//
//  ViewController.swift
//  cm_02
//
//  Created by Germán Santos Jaimes on 02/09/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    
    @IBOutlet weak var mySlider: UISlider!
    
    var contador: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clickme(_ sender: UIButton) {
        contador = contador + 1
        letrero.text = String(contador)
    }
    
    @IBAction func resetContador(_ sender: UIButton){
        contador = 0
        letrero.text = String(contador)
    }
    
    
    @IBAction func myAction(_ sender: UISlider) {
        var valor = Int(mySlider.value)
        letrero.text = String(valor)
    }
    
}

