//
//  ViewController.swift
//  cm_01
//
//  Created by Germán Santos Jaimes on 14/08/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        letrero.backgroundColor = UIColor.red
        
    }


}

