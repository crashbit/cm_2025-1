//
//  Vista2ViewController.swift
//  cm_05
//
//  Created by Germán Santos Jaimes on 09/09/24.
//

import UIKit

class Vista2ViewController: UIViewController {

    @IBOutlet weak var etiqueta: UILabel!
    var recibe = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        etiqueta.text = recibe
        print(recibe)
    }
    

    

}
