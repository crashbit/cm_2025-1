//
//  ViewController.swift
//  cm_07
//
//  Created by Germán Santos Jaimes on 18/09/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var alumnos:[String] = ["Juan", "Pedro", "Luis", "Diana"]
    @IBOutlet weak var tabla : UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CeldaTableViewCell
        
        cell.letrero.text = alumnos[indexPath.row]
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var MyindexPath = tabla.indexPathForSelectedRow
        var info = alumnos[MyindexPath!.row]
        let vista2 = segue.destination as! Vista2ViewController
        vista2.recibe = info
    }


}

